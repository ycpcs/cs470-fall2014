#include "M3DMesh.h"

// Constructors
M3DMesh::M3DMesh()
{
	// Initialize local transformation to identity
	XMMATRIX Ident = XMMatrixIdentity();
	XMStoreFloat4x4(&World, Ident);
}

M3DMesh::M3DMesh(ID3D11Device* device, const std::string& modelFilename)
{
	Init(device, modelFilename);
}

// Destructor
M3DMesh::~M3DMesh()
{

}

// Initialization
void M3DMesh::Init(ID3D11Device* device, const std::string& modelFilename)
{
	// TODO: Read file and create buffers for mesh

}

// Model loader
bool M3DMesh::loadM3DMesh(const std::string& modelFilename)
{

	// Local variables
	UINT numVertices = 0;
	UINT numTriangles = 0;
	std::string ignore;

	// TODO: Open .m3d mesh file
	
	
	return false;
}

void M3DMesh::ReadSubsetTable(std::ifstream& fin, UINT numSubsets)
{
	std::string ignore;
	Subsets.resize(numSubsets);

	// TODO: Read subset table

}

void M3DMesh::ReadVertices(std::ifstream& fin, UINT numVertices)
{
	std::string ignore;
	Vertices.resize(numVertices);
	
	// TODO: Read vertex data

}

void M3DMesh::ReadTriangles(std::ifstream& fin, UINT numTriangles)
{

	std::string ignore;
	Indices.resize(numTriangles * 3);

	// TODO: Read index data

}
