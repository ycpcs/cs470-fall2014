#include "d3dApp.h"
#include "M3DMesh.h"
#include <string>

// Subclass declaration
class BasicMeshApp : public D3DApp
{
private:
	// TODO: Class attributes

	// Shader variables
	std::wstring mFXFileName;
	ID3DX11Effect* mFX;
	ID3DX11EffectTechnique* mTech;
	ID3DX11EffectMatrixVariable* mFXMatVar;

	// Vertex buffer
	ID3D11InputLayout* mVertexLayout;

	// Global transformations
	XMFLOAT4X4 mView;
	XMFLOAT4X4 mProj;
	XMFLOAT4X4 mWVP;

	// Camera vectors
	XMFLOAT3 mEye;
	XMFLOAT3 mAt;
	XMFLOAT3 mUp;

public:
	BasicMeshApp(HINSTANCE);
	~BasicMeshApp();

	// Overriden methods
	bool Init();
	void OnResize();
	void UpdateScene(float dt);
	void DrawScene();

private:
	// TODO: Shader methods
	void buildFX();
	void buildVertexLayouts();

};