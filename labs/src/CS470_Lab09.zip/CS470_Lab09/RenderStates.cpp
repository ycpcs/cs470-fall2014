//***************************************************************************************
// RenderStates.cpp by Frank Luna (C) 2011 All Rights Reserved.
//***************************************************************************************

#include "RenderStates.h"

//TODO: Implement blend state struct

////////////////////////////////////////////////////////////

void RenderStates::InitAll(ID3D11Device* device)
{
	
	//TODO: init a D3D11_BLEND_DESC

	//TODO: init a D3D11_BLEND_DESC

	//TODO: set blending factors

	//TODO: set blending factors

	//TODO: call CreateBlendState
	
}

void RenderStates::DestroyAll()
{
	ReleaseCOM(TransparentBS);
}