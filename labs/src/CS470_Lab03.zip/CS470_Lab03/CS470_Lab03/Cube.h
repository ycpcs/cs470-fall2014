#ifndef CUBE_H
#define CUBE_H

#include "d3dUtil.h"

// Class declaration
class Cube
{
	// Attributes
private:

	// Methods
public:
	Cube();
	~Cube();

	void Init(ID3D11Device* device);
	void Draw(ID3D11DeviceContext* immediateContext);
};

#endif	// CUBE_H