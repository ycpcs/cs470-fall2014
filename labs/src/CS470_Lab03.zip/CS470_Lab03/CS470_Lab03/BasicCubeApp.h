#include "d3dApp.h"
#include "Cube.h"
#include <string>

// Subclass declaration
class BasicCubeApp : public D3DApp
{
private:
	// TODO: Class attributes

public:
	BasicCubeApp(HINSTANCE);
	~BasicCubeApp();

	// Overriden methods
	bool Init();
	void OnResize();
	void UpdateScene(float dt);
	void DrawScene();

private:
	// TODO: Shader methods

};