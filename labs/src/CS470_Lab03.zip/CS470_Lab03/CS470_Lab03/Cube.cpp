#include "Cube.h"

// Constructor
Cube::Cube()
{

}

// Destructor
Cube::~Cube()
{

}

// Initialization
void Cube::Init(ID3D11Device* device)
{

}

// Render
void Cube::Draw(ID3D11DeviceContext* immediateContext)
{

}