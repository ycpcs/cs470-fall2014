// Include base class declaration
#include "BasicCubeApp.h"

// Class methods
BasicCubeApp::BasicCubeApp(HINSTANCE hInstance) : D3DApp(hInstance), mFX(0), mTech(0), mVertexLayout(0), mFXMatVar(0)
{
	// TODO: Initialize class fields

};

BasicCubeApp::~BasicCubeApp()
{

};

bool BasicCubeApp::Init()
{
	// Simply use base class initializer
	if (!D3DApp::Init())
	{
		return false;
	}

	// TODO: Additional initializations

	return true;
}

void BasicCubeApp::OnResize()
{
	// Simply use base class resize
	D3DApp::OnResize();

	// TODO: Reset projection matrix

}

void BasicCubeApp::UpdateScene(float dt)
{};

void BasicCubeApp::DrawScene()
{
	// Check for valid rendering context and swap chain
	assert(md3dImmediateContext);
	assert(mSwapChain);

	// Simply clear render view to blue
	md3dImmediateContext->ClearRenderTargetView(mRenderTargetView, reinterpret_cast<const float*>(&Colors::Blue));

	// Clear depth buffer to 1.0 and stenci buffer to 0
	md3dImmediateContext->ClearDepthStencilView(mDepthStencilView, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

	// TODO: Set input layout to object vertices

	// TODO: Set topology (triangle list)

	// TODO: Compute total modelview-projection matrix

	// TODO: Get technique and loop over passes

	// Swap back buffer
	HR(mSwapChain->Present(0, 0));
};

// Build effect
void BasicCubeApp::buildFX()
{
	// Set shader flags
	DWORD shaderFlags = 0;
#if defined(DEBUG) | defined(_DEBUG)
	shaderFlags |= D3D10_SHADER_DEBUG;
	shaderFlags |= D3D10_SHADER_SKIP_OPTIMIZATION;
#endif

	//TODO: Create shader

	// TODO: Create effect from shader

	// TODO: Set technique and associate variables

}

// Build vertex layout
void BasicCubeApp::buildVertexLayouts()
{
	// TODO: Create vertex layout

}

// Windows main function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE prevInstance, PSTR cmdLine, int showCmd)
{
	// Add some debug flags if debugging
#if defined(DEBUG) | defined(_DEBUG)
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

	// Instantiate application object
	BasicCubeApp theApp(hInstance);

	// Initialize the application
	if (!theApp.Init())
	{
		return 0;
	}

	// Execute the application
	return theApp.Run();
}